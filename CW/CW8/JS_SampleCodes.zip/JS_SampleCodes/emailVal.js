<!--- Simple regular expression to validate email address --->


<script type ="text/javascript">
function validateEmail(email)